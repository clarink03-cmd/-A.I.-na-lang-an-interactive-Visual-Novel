## game/build.rpy
## Build configuration for A.I. na lang!

init python:
    build.name = "AInaLang"
    build.executable_name = "AInaLang"